package com.fayardev.regms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegMSApplicationTests {

    @Test
    void contextLoads() {
    }

}
