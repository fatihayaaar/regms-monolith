package com.fayardev.regms.exceptions.enums;

public enum ErrorComponents {

    USERNAME,
    EMAIL,
    PASSWORD,
    GENDER,
    ABOUT_ME,
    AVATAR,
    USER,
    NAME_AND_SURNAME
}
