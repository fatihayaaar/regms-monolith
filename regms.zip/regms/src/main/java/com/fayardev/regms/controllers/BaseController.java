package com.fayardev.regms.controllers;

public class BaseController {

    protected BaseController() {
    }
}
