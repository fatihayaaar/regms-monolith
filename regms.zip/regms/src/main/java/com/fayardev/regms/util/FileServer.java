package com.fayardev.regms.util;

public class FileServer {

    private static String FILE_SERVER_ADDRESS = "192.168.1.1:8081";

    public static void uploadAvatar(String base64, String path) {

    }
}
